<?php

namespace App\Http\Models;

use DB;
use Illuminate\Database\Eloquent\Model;

class CurrencyModel extends Model {

    protected $table = 'currency';

   
}
