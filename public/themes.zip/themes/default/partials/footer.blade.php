<!-- Footer -->
<footer>
    <div class="row">
        <div class="col-lg-12">
            <p>Copyright &copy; KursRupiah.info 2015</p>
        </div>
    </div>
</footer>
